from zoompy import __version__
from zoompy import zoompy
import pytest

def test_version():
    assert __version__ == '1.0.0'

