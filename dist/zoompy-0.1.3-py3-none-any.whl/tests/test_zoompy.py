from zoompy import __version__
from zoompy import zoompy
import pytest

def test_version():
    assert __version__ == '0.1.3'

